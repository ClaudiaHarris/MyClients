import React from "react";
import ClientScreen from "./pages/ClientScreen";

function App() {
  return <ClientScreen />;
}

export default App; //TODO resolve conflict app.js and index.js