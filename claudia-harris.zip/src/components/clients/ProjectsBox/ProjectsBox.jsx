// src/components/clients/ProjectsBox/ProjectsBox.jsx
import React, { useState, useEffect } from 'react';
import supabase from '../../../config/supabaseClient';
import ProjectTabs from './ProjectTabs';
import ProjectList from './ProjectList';
import './ProjectsBox.css';

const ProjectsBox = ({ clientId }) => {
  const [activeTab, setActiveTab] = useState('all');
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        setError(null);
        
        const { data, error: fetchError } = await supabase
          .from('projects')
          .select('*')
          .eq('client_id', clientId);

        if (fetchError) {
          throw fetchError;
        }

        setProjects(data || []);
      } catch (err) {
        console.error('Error fetching projects:', err);
        setError('Failed to load projects');
      } finally {
        setLoading(false);
      }
    };

    if (clientId) {
      fetchProjects();
    }
  }, [clientId]);

  // Filter projects based on the active tab
  const filteredProjects = activeTab === 'all' 
    ? projects 
    : projects.filter(project => project.project_status === activeTab);

  if (loading) {
    return <div className="loading-message">Loading projects...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="projects-box">
      <div className="projects-card-content">
        <div className="projects-card-header">
          <h2>Projects</h2>
        </div>

        <ProjectTabs 
          activeTab={activeTab} 
          onTabChange={setActiveTab} 
          projectCounts={{
            all: projects.length,
            pending: projects.filter(p => p.project_status === 'pending').length,
            active: projects.filter(p => p.project_status === 'active').length,
            closed: projects.filter(p => p.project_status === 'closed').length
          }}
        />
        
        <ProjectList projects={filteredProjects} />
      </div>
    </div>
  );
};

export default ProjectsBox;